import React, { useState } from 'react'

const Home = () => {

    const [title, setTitle] = useState('')
    const [description, setDescription] = useState('')

    const [todos, setTodos] = useState(localStorage.getItem('data') ? JSON.parse(localStorage.getItem('data')) : [])

    const handleTitleChange = (e) => {
        setTitle(e.target.value)
    }
    const handleDescChange = (e) => {
        setDescription(e.target.value)
    }

    const handleSave = () => {
        const newTodo = {
            id: Math.floor(Math.random() * Date.now()),
            title: title,
            description: description
        }

        setTodos([...todos, newTodo]);
        localStorage.setItem('data', JSON.stringify(todos))
    }
    return (
        <div style={{ backgroundColor: 'green', padding: '100px' }} className='container'>
            <div className="mb-3">
                <label htmlFor="title" className="form-label">Title</label>
                <input type="text" onChange={(e) => handleTitleChange(e)} className="form-control" id="title" placeholder="Enter the Title" />
            </div>
            <div className="mb-3">
                <label htmlFor="description" className="form-label">Description</label>
                <input type="text" onChange={(e) => handleDescChange(e)} className="form-control" id="description" placeholder="Description" />
            </div>
            <div className="mb-3">

                <input type="button" onClick={handleSave} className="btn btn-primary w-100" value="Add" />
            </div>
            {
                todos.length === 0 ? <h3>No Data Found...</h3> : todos.map(todo => {
                    return (
                        <>
                            <h3>{todo.title}</h3>
                            <p>{todo.description}</p>
                        </>
                    )
                })
            }
        </div>
    )
}

export default Home