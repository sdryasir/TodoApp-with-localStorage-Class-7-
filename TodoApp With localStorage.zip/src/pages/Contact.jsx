import React from 'react'

const Contact = () => {
    return (
        <div style={{ backgroundColor: 'red', padding: '100px' }}>This is a contact Page</div>
    )
}

export default Contact