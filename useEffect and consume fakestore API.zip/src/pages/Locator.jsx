import React from 'react'

const Locator = () => {
    return (
        <div style={{ backgroundColor: 'yellow', padding: '100px' }}>Thos is the locator page</div>
    )
}

export default Locator