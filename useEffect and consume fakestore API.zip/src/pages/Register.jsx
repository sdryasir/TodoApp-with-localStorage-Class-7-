import React from 'react'

const Register = () => {
    return (
        <div style={{ backgroundColor: 'grey', padding: '100px' }}>This is a Register Page</div>
    )
}

export default Register