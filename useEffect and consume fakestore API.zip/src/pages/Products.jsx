import React, { useEffect, useState } from "react";
import StarsRating from 'stars-rating'

const Products = () => {
  const [products, setProducts] = useState([]);


  const [prod, setProd] = useState({})
  useEffect(() => {


    fetch("https://fakestoreapi.com/products/")
      .then((res) => res.json())
      .then((data) => setProducts(data));
  }, []);

  return (
    <div className="row">
      {products.map((product) => {
        return (
            <div className="col-md-4">
                <div class="card">
                <img style={{width:"200px"}} src={product.image} class="card-img-top" alt="..." />
                <div class="card-body">
                    <h5 class="card-title">{product.title}</h5>
                    <p>Price: <strong>${product.price}</strong></p>
                    <StarsRating
                        count={product.rating.rate}
                        size={24}
                        color2={'#ffd700'} />
                        <span>({product.rating.count})</span>
                </div>
                </div>
            </div>
        );
      })}
    </div>
  );
};

export default Products;
