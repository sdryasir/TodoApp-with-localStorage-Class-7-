import React from 'react'

const Login = () => {
    return (
        <div style={{ backgroundColor: 'orange', padding: '100px' }}>This is a login page</div>
    )
}

export default Login